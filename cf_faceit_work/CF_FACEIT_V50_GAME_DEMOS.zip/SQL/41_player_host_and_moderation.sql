-- CF FACEIT v46: player-owned room flow, enforced matchmaking restrictions,
-- staff cooperation badge, day-based bans and temporary match-launch limits.
-- Run after matchmaking SQL/10-16, timer SQL/21 and SQL/35, moderation SQL/28,
-- cooldown SQL/30, regional matchmaking SQL/39 and support SQL/40. Does not alter Elo/results.

begin;

do $roles$
declare c record;
begin
  for c in
    select conname from pg_constraint
    where conrelid='public.profiles'::regclass
      and contype='c'
      and pg_get_constraintdef(oid) ilike '%role%'
  loop
    execute format('alter table public.profiles drop constraint %I',c.conname);
  end loop;
  alter table public.profiles
    add constraint profiles_role_allowed
    check (role in ('player','tester','cooperation','admin','founder'));
end;
$roles$;

-- Require SQL/28's private moderation table; never expose ban data on profiles.
do $check$
begin
  if to_regclass('public.cf_player_moderation') is null then
    raise exception 'Сначала выполни SQL/28_v30_prime_bans_banners.sql.';
  end if;
  if to_regprocedure('public.cf_lobby_match_state()') is null
     or to_regprocedure('public.cf_matchmaking_try_form(text,text)') is null then
    raise exception 'Сначала установи matchmaking SQL/10-16 и SQL/39.';
  end if;
  if not exists (
    select 1 from pg_trigger t
    join pg_proc p on p.oid=t.tgfoid
    where t.tgrelid='public.cf_lobby_matches'::regclass
      and p.proname='cf_match_auto_live' and not t.tgisinternal
  ) then
    raise exception 'Сначала установи SQL/21_auto_match_live.sql и SQL/35_match_timer_and_screenshot_fix.sql.';
  end if;
end;
$check$;

-- Keep stored, bounded HTTPS/custom-image avatars in every server-backed list.
create or replace function public.cf_lobby_user_json(p_uid uuid)
returns jsonb language sql stable security definer set search_path=public as $$
  select jsonb_build_object(
    'id',p.id,'nickname',p.nickname,
    'display_name',coalesce(nullif(p.display_name,''),p.nickname),
    'avatar',case
      when char_length(coalesce(p.avatar,''))<=1000 and p.avatar ~* '^https://[^[:space:]]+$' then p.avatar
      when char_length(coalesce(p.avatar,''))<=40000 and p.avatar ~ '^data:image/(png|jpeg|webp|gif);base64,' then p.avatar
      when p.avatar in ('ember','steel','azure','moss','plum','sand') then p.avatar
      else 'ember' end,
    'elo',coalesce(p.elo,800),'verified',coalesce(p.verified,false),'role',coalesce(p.role,'player')
  ) from public.profiles p where p.id=p_uid
$$;
create or replace function public.cf_friend_profile(p_uid uuid)
returns jsonb language sql stable security definer set search_path=public as $$
  select public.cf_lobby_user_json(p_uid)
$$;

alter table public.cf_lobby_matches
  add column if not exists live_started_at timestamptz,
  add column if not exists play_ends_at timestamptz;

alter table public.cf_player_moderation
  add column if not exists match_restricted_until timestamptz,
  add column if not exists match_restriction_reason text not null default '';

-- Staff lookup: only trusted admins/founder can assign roles. Cooperation is
-- a separate role, not an admin privilege; its blue badge is rendered by role.
create or replace function public.cf_manage_staff_lookup(
  p_target text,
  p_role text,
  p_verified boolean default false
)
returns jsonb
language plpgsql
security definer
set search_path=public,auth
as $function$
declare
  v_actor uuid:=auth.uid();
  v_actor_role text;
  v_target uuid;
  v_target_role text;
  v_nickname text;
begin
  if v_actor is null then raise exception 'Нужно войти в аккаунт'; end if;
  if nullif(trim(p_target),'') is null then raise exception 'Укажи ник, почту, игровой ID или UUID'; end if;
  if p_role is null or p_role not in ('player','tester','cooperation','admin') then
    raise exception 'Недопустимая роль';
  end if;
  select role into v_actor_role from public.profiles where id=v_actor;
  if coalesce(v_actor_role,'player') not in ('founder','admin') then raise exception 'Недостаточно прав'; end if;

  if trim(p_target) ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then
    select id,role,nickname into v_target,v_target_role,v_nickname
    from public.profiles where id=trim(p_target)::uuid;
  elsif position('@' in p_target)>0 then
    select p.id,p.role,p.nickname into v_target,v_target_role,v_nickname
    from auth.users u join public.profiles p on p.id=u.id
    where lower(u.email)=lower(trim(p_target)) limit 1;
  elsif trim(p_target) ~ '^[0-9]{6,7}$' then
    select id,role,nickname into v_target,v_target_role,v_nickname
    from public.profiles where game_id=trim(p_target) limit 1;
  else
    select id,role,nickname into v_target,v_target_role,v_nickname
    from public.profiles where lower(nickname)=lower(trim(p_target)) limit 1;
  end if;

  if v_target is null then raise exception 'Игрок не найден. Проверь ник, почту, ID или UUID'; end if;
  if v_target_role='founder' then raise exception 'Нельзя изменить роль основателя'; end if;
  if v_actor_role='admin' then
    if p_role='admin' then raise exception 'Только основатель может выдавать админку'; end if;
    if v_target_role='admin' then raise exception 'Администратор не может менять права другого администратора'; end if;
    if v_target=v_actor then raise exception 'Нельзя изменять собственные права'; end if;
  end if;

  update public.profiles set role=p_role,verified=coalesce(p_verified,false) where id=v_target;
  return jsonb_build_object('ok',true,'user_id',v_target,'nickname',v_nickname,
    'role',p_role,'verified',coalesce(p_verified,false));
end;
$function$;
revoke all on function public.cf_manage_staff_lookup(text,text,boolean) from public,anon;
grant execute on function public.cf_manage_staff_lookup(text,text,boolean) to authenticated;

-- Status endpoint reports only the signed-in player's own moderation details.
create or replace function public.cf_my_moderation()
returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $function$
declare v_uid uuid:=auth.uid(); v_row public.cf_player_moderation%rowtype;
begin
  if v_uid is null then raise exception 'Нужно войти в аккаунт'; end if;
  select * into v_row from public.cf_player_moderation where user_id=v_uid;
  if not found then
    return jsonb_build_object('is_permanently_banned',false,'banned_until',null,'ban_reason','',
      'match_restricted_until',null,'match_restriction_reason','');
  end if;
  return jsonb_build_object(
    'is_permanently_banned',coalesce(v_row.is_permanently_banned,false),
    'banned_until',case when v_row.banned_until>clock_timestamp() then v_row.banned_until else null end,
    'ban_reason',case when v_row.is_permanently_banned or v_row.banned_until>clock_timestamp() then v_row.ban_reason else '' end,
    'match_restricted_until',case when v_row.match_restricted_until>clock_timestamp() then v_row.match_restricted_until else null end,
    'match_restriction_reason',case when v_row.match_restricted_until>clock_timestamp() then v_row.match_restriction_reason else '' end);
end;
$function$;
revoke all on function public.cf_my_moderation() from public,anon;
grant execute on function public.cf_my_moderation() to authenticated;

-- Set/remove a temporary match-launch limit. 0 days removes the limit.
create or replace function public.cf_admin_set_match_restriction(
  p_target text,
  p_days integer,
  p_reason text default ''
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $function$
declare
  v_actor uuid:=auth.uid();
  v_actor_role text;
  v_target public.profiles%rowtype;
  v_until timestamptz;
  v_reason text:=left(trim(coalesce(p_reason,'')),300);
begin
  if v_actor is null then raise exception 'Нужно войти в аккаунт'; end if;
  select role into v_actor_role from public.profiles where id=v_actor;
  if coalesce(v_actor_role,'player') not in ('admin','founder') then raise exception 'Недостаточно прав'; end if;
  if p_days is null or p_days<0 or p_days>3650 then raise exception 'Срок должен быть от 0 до 3650 дней'; end if;
  select * into v_target from public.profiles
  where lower(nickname)=lower(trim(p_target)) or game_id=trim(p_target) or id::text=trim(p_target)
  order by case when lower(nickname)=lower(trim(p_target)) then 0 when game_id=trim(p_target) then 1 else 2 end
  limit 1 for update;
  if not found then raise exception 'Игрок не найден'; end if;
  if v_target.id=v_actor then raise exception 'Нельзя ограничить самого себя'; end if;
  if coalesce(v_target.role,'player') in ('admin','founder') then raise exception 'Нельзя ограничить запуск матчей администратору или основателю'; end if;

  if p_days=0 then
    update public.cf_player_moderation
      set match_restricted_until=null,match_restriction_reason='',updated_at=clock_timestamp(),updated_by=v_actor
      where user_id=v_target.id;
    return jsonb_build_object('ok',true,'id',v_target.id,'nickname',v_target.nickname,'match_restricted_until',null,'removed',true);
  end if;
  if v_reason='' then raise exception 'Укажи причину ограничения'; end if;
  v_until:=clock_timestamp()+make_interval(days=>p_days);
  insert into public.cf_player_moderation(user_id,match_restricted_until,match_restriction_reason,updated_at,updated_by)
  values(v_target.id,v_until,v_reason,clock_timestamp(),v_actor)
  on conflict(user_id) do update set match_restricted_until=excluded.match_restricted_until,
    match_restriction_reason=excluded.match_restriction_reason,updated_at=excluded.updated_at,updated_by=excluded.updated_by;

  update public.cf_matchmaking_queue q set queue_status='cancelled',updated_at=clock_timestamp()
  where q.queue_status='queued' and v_target.id=any(q.party_ids);
  update public.cf_lobby_matches m set status='cancelled',cancel_reason='Запуск матчей временно ограничен администратором',updated_at=clock_timestamp()
  where v_target.id=any(m.participant_ids)
    and m.status in ('searching','found','choose_host','host_selected','pending_admin','taken','room','joined');

  return jsonb_build_object('ok',true,'id',v_target.id,'nickname',v_target.nickname,'match_restricted_until',v_until,'reason',v_reason);
end;
$function$;
revoke all on function public.cf_admin_set_match_restriction(text,integer,text) from public,anon;
grant execute on function public.cf_admin_set_match_restriction(text,integer,text) to authenticated;

-- Recreate the existing ban RPC with queue/pre-start cleanup. p_hours remains
-- compatible with SQL/28 and the deployed site; the UI now accepts days.
create or replace function public.cf_admin_set_ban(p_target text,p_hours integer,p_reason text default '')
returns jsonb
language plpgsql
security definer
set search_path=public
as $function$
declare
  v_uid uuid:=auth.uid(); v_role text; v_target public.profiles%rowtype;
  v_until timestamptz; v_perm boolean:=false; v_reason text:=left(trim(coalesce(p_reason,'')),300);
begin
  if v_uid is null then raise exception 'Нужно войти в аккаунт'; end if;
  select role into v_role from public.profiles where id=v_uid;
  if coalesce(v_role,'player') not in ('admin','founder') then raise exception 'Недостаточно прав'; end if;
  if p_hours is null or p_hours < -1 or p_hours > 87600 then raise exception 'Недопустимый срок блокировки'; end if;
  select * into v_target from public.profiles
  where lower(nickname)=lower(trim(p_target)) or game_id=trim(p_target) or id::text=trim(p_target)
  order by case when lower(nickname)=lower(trim(p_target)) then 0 when game_id=trim(p_target) then 1 else 2 end
  limit 1 for update;
  if not found then raise exception 'Игрок не найден'; end if;
  if v_target.id=v_uid then raise exception 'Нельзя заблокировать самого себя'; end if;
  if coalesce(v_target.role,'player') in ('admin','founder') then raise exception 'Нельзя заблокировать администратора или основателя через эту форму'; end if;

  if p_hours=-1 then
    update public.cf_player_moderation set banned_until=null,is_permanently_banned=false,ban_reason='',updated_at=clock_timestamp(),updated_by=v_uid
    where user_id=v_target.id;
    return jsonb_build_object('ok',true,'id',v_target.id,'nickname',v_target.nickname,'banned_until',null,'is_permanently_banned',false,'unbanned',true);
  elsif p_hours=0 then
    v_perm:=true; v_until:=null;
  else
    v_until:=clock_timestamp()+make_interval(hours=>p_hours);
  end if;
  if v_reason='' then raise exception 'Укажи причину блокировки'; end if;
  insert into public.cf_player_moderation(user_id,banned_until,is_permanently_banned,ban_reason,updated_at,updated_by)
  values(v_target.id,v_until,v_perm,v_reason,clock_timestamp(),v_uid)
  on conflict(user_id) do update set banned_until=excluded.banned_until,is_permanently_banned=excluded.is_permanently_banned,
    ban_reason=excluded.ban_reason,updated_at=excluded.updated_at,updated_by=excluded.updated_by;

  update public.cf_matchmaking_queue q set queue_status='cancelled',updated_at=clock_timestamp()
  where q.queue_status='queued' and v_target.id=any(q.party_ids);
  update public.cf_lobby_matches m set status='cancelled',cancel_reason='Аккаунт заблокирован администратором',updated_at=clock_timestamp()
  where v_target.id=any(m.participant_ids)
    and m.status in ('searching','found','choose_host','host_selected','pending_admin','taken','room','joined');

  return jsonb_build_object('ok',true,'id',v_target.id,'nickname',v_target.nickname,'banned_until',v_until,'is_permanently_banned',v_perm,'ban_reason',v_reason);
end;
$function$;
revoke all on function public.cf_admin_set_ban(text,integer,text) from public,anon;
grant execute on function public.cf_admin_set_ban(text,integer,text) to authenticated;

-- Queue inserts are a second server-side guard in addition to the RPC check.
create or replace function public.cf_v46_guard_restricted_queue()
returns trigger
language plpgsql
security definer
set search_path=public
as $function$
begin
  if new.queue_status='queued' and exists (
    select 1 from unnest(new.party_ids) as member(user_id)
    join public.cf_player_moderation moderation on moderation.user_id=member.user_id
    where moderation.is_permanently_banned
       or moderation.banned_until>clock_timestamp()
       or moderation.match_restricted_until>clock_timestamp()
  ) then
    raise exception 'В составе лобби есть игрок, которому запрещено запускать матчи';
  end if;
  return new;
end;
$function$;
revoke all on function public.cf_v46_guard_restricted_queue() from public,anon,authenticated;
drop trigger if exists cf_v46_guard_restricted_queue on public.cf_matchmaking_queue;
create trigger cf_v46_guard_restricted_queue
before insert or update of queue_status,party_ids on public.cf_matchmaking_queue
for each row execute function public.cf_v46_guard_restricted_queue();

-- An unaccepted/single player is still a valid matchmaking party: create exactly
-- one private lobby on demand, but never create duplicate solo lobbies.
create or replace function public.cf_lobby_match_start(p_mode text,p_map text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $function$
declare
  v_uid uuid:=auth.uid(); v_lobby uuid; v_ids uuid[]; v_count integer;
  v_team_size integer; v_active uuid; v_region text;
  v_banned boolean:=false; v_ban_until timestamptz; v_ban_reason text;
  v_restricted_until timestamptz; v_restriction_reason text;
begin
  if v_uid is null then raise exception 'Нужно войти в аккаунт'; end if;
  if p_mode not in ('ranked','duo') then raise exception 'Недопустимый режим'; end if;
  if p_map not in ('Mirage','Dust2','Vertigo','Inferno') then raise exception 'Недопустимая карта'; end if;
  v_team_size:=case when p_mode='duo' then 2 else 5 end;

  select coalesce(p.region,'ru') into v_region from public.profiles p where p.id=v_uid;
  if not found then raise exception 'Профиль не найден. Перезайди в аккаунт'; end if;
  select m.is_permanently_banned,m.banned_until,m.ban_reason,m.match_restricted_until,m.match_restriction_reason
    into v_banned,v_ban_until,v_ban_reason,v_restricted_until,v_restriction_reason
  from public.cf_player_moderation m where m.user_id=v_uid;
  if coalesce(v_banned,false) or v_ban_until>clock_timestamp() then
    raise exception 'Аккаунт заблокирован: %',coalesce(nullif(v_ban_reason,''),'обратись в поддержку');
  end if;
  if v_restricted_until>clock_timestamp() then
    raise exception 'Запуск матчей ограничен до %: %',to_char(v_restricted_until at time zone 'UTC','YYYY-MM-DD HH24:MI UTC'),coalesce(nullif(v_restriction_reason,''),'обратись к администратору');
  end if;
  if v_region not in ('ru','eu','asia','all') then raise exception 'Недопустимый регион'; end if;

  perform pg_advisory_xact_lock(hashtext('cf:v9:queue-user:'||v_uid::text));
  select lm.lobby_id into v_lobby from public.lobby_members lm where lm.user_id=v_uid;
  if v_lobby is null then
    insert into public.lobbies(owner_id) values(v_uid) returning id into v_lobby;
    insert into public.lobby_members(lobby_id,user_id) values(v_lobby,v_uid);
  end if;

  select m.id into v_active from public.cf_lobby_matches m
  where v_uid=any(m.participant_ids) and m.status not in ('done','cancelled')
  order by m.created_at desc limit 1;
  if v_active is not null then return public.cf_lobby_match_state(); end if;

  select array_agg(user_id order by joined_at),count(*) into v_ids,v_count
  from public.lobby_members where lobby_id=v_lobby;
  if coalesce(v_count,0)<1 then raise exception 'Лобби пустое. Создай группу и попробуй ещё раз'; end if;
  if v_count>v_team_size then
    raise exception 'В режиме % можно сохранить в одной группе максимум % игроков. Разделите лобби или выберите 5×5.',p_mode,v_team_size;
  end if;
  if exists (
    select 1 from unnest(v_ids) as member(user_id)
    join public.cf_player_moderation moderation on moderation.user_id=member.user_id
    where moderation.is_permanently_banned or moderation.banned_until>clock_timestamp()
       or moderation.match_restricted_until>clock_timestamp()
  ) then raise exception 'В составе лобби есть игрок, которому запрещено запускать матчи'; end if;

  if v_region<>'all' and exists (
    select 1 from unnest(v_ids) as member(user_id)
    left join public.profiles p on p.id=member.user_id
    where p.id is null or coalesce(p.region,'ru') not in (v_region,'all')
  ) then raise exception 'У всех игроков в лобби должен совпадать регион или стоять «Все регионы». Попроси друзей изменить регион в настройках.'; end if;

  if exists(select 1 from public.cf_matchmaking_queue q where q.lobby_id=v_lobby and q.queue_status='queued') then
    return public.cf_lobby_match_state();
  end if;
  insert into public.cf_matchmaking_queue(lobby_id,party_ids,mode,map_name,region)
  values(v_lobby,v_ids,p_mode,p_map,v_region);
  perform public.cf_matchmaking_try_form(p_mode,v_region);
  return public.cf_lobby_match_state();
end;
$function$;
revoke all on function public.cf_lobby_match_start(text,text) from public,anon;
grant execute on function public.cf_lobby_match_start(text,text) to authenticated;

-- Matchmaking participants choose a player host only; admins cannot create or publish rooms.
create or replace function public.cf_lobby_match_choose_host(p_choice text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $function$
declare v_uid uuid:=auth.uid(); v_match public.cf_lobby_matches%rowtype; v_host uuid; v_host_nick text;
begin
  if v_uid is null then raise exception 'Нужно войти в аккаунт'; end if;
  if p_choice is distinct from 'player' then raise exception 'Комнату может создать только игрок-участник матча'; end if;
  select * into v_match from public.cf_lobby_matches m
  where v_uid=any(m.participant_ids) and m.status='choose_host'
  order by m.created_at desc limit 1 for update;
  if not found then raise exception 'Выбор организатора уже закрыт'; end if;
  select uid into v_host from unnest(v_match.participant_ids) as x(uid) order by random() limit 1;
  select nickname into v_host_nick from public.profiles where id=v_host;
  update public.cf_lobby_matches
  set host_choice='player',room_host_id=v_host,room_host_nickname=coalesce(v_host_nick,'Игрок'),
      admin_id=null,admin_nickname='',status='host_selected',updated_at=clock_timestamp()
  where id=v_match.id;
  return public.cf_lobby_match_state();
end;
$function$;
revoke all on function public.cf_lobby_match_choose_host(text) from public,anon;
grant execute on function public.cf_lobby_match_choose_host(text) to authenticated;

-- Publishing a room code leaves it cancellable; it must not start the timer.
create or replace function public.cf_lobby_match_player_publish_code(p_code text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $function$
declare v_uid uuid:=auth.uid(); v_match public.cf_lobby_matches%rowtype; v_nick text;
begin
  if v_uid is null then raise exception 'Нужно войти в аккаунт'; end if;
  if nullif(trim(p_code),'') is null or char_length(trim(p_code))>64 then
    raise exception 'Введи код комнаты длиной от 1 до 64 символов';
  end if;
  select * into v_match from public.cf_lobby_matches m
  where v_uid=m.room_host_id and m.status='host_selected'
  order by m.created_at desc limit 1 for update;
  if not found then raise exception 'Только выбранный игрок-организатор может опубликовать код'; end if;
  select nickname into v_nick from public.profiles where id=v_uid;
  update public.cf_lobby_matches
  set status='room',room_code=trim(p_code),admin_id=null,
      admin_nickname=coalesce(v_nick,'Игрок'),updated_at=clock_timestamp()
  where id=v_match.id;
  return public.cf_lobby_match_state();
end;
$function$;
revoke all on function public.cf_lobby_match_player_publish_code(text) from public,anon;
grant execute on function public.cf_lobby_match_player_publish_code(text) to authenticated;

-- Start the game only after the selected player confirms everyone is in the room.
create or replace function public.cf_lobby_match_player_start()
returns jsonb
language plpgsql
security definer
set search_path=public
as $function$
declare v_uid uuid:=auth.uid(); v_match public.cf_lobby_matches%rowtype;
begin
  if v_uid is null then raise exception 'Нужно войти в аккаунт'; end if;
  select * into v_match from public.cf_lobby_matches m
  where m.room_host_id=v_uid and m.status='room'
  order by m.created_at desc limit 1 for update;
  if not found then raise exception 'Только организатор может начать матч после публикации кода комнаты'; end if;
  update public.cf_lobby_matches set status='joined',updated_at=clock_timestamp() where id=v_match.id;
  return public.cf_lobby_match_state();
end;
$function$;
revoke all on function public.cf_lobby_match_player_start() from public,anon;
grant execute on function public.cf_lobby_match_player_start() to authenticated;

-- Replace the old auto-live-on-room trigger behavior. Creating/publishing a
-- room leaves status='room'; the player-start RPC transitions joined -> live.
create or replace function public.cf_match_auto_live()
returns trigger
language plpgsql
set search_path=public
as $function$
declare v_now timestamptz:=clock_timestamp();
begin
  if new.status='joined' and old.status is distinct from 'joined' then
    new.status:='live';
    new.live_started_at:=v_now;
    new.play_ends_at:=v_now+interval '15 minutes';
  elsif new.status='live' and old.status is distinct from 'live' then
    new.live_started_at:=coalesce(new.live_started_at,v_now);
    new.play_ends_at:=coalesce(new.play_ends_at,new.live_started_at+interval '15 minutes');
  end if;
  return new;
end;
$function$;

-- Admins may still cancel a match and review submitted results, but cannot take
-- over or publish room codes. The room lifecycle belongs to the player host.
create or replace function public.cf_lobby_match_admin_action(p_match uuid,p_action text,p_code text default null)
returns jsonb
language plpgsql
security definer
set search_path=public
as $function$
declare v_uid uuid:=auth.uid(); v_role text; v_match public.cf_lobby_matches%rowtype;
begin
  if v_uid is null then raise exception 'Нужно войти в аккаунт'; end if;
  select role into v_role from public.profiles where id=v_uid;
  if coalesce(v_role,'player') not in ('admin','founder') then raise exception 'Недостаточно прав'; end if;
  if p_action is distinct from 'cancel' then raise exception 'Комнату и код настраивает выбранный игрок-организатор'; end if;
  select * into v_match from public.cf_lobby_matches where id=p_match for update;
  if not found then raise exception 'Матч не найден'; end if;
  if v_match.status in ('done','cancelled') then raise exception 'Матч уже завершён'; end if;
  update public.cf_lobby_matches set status='cancelled',cancel_reason='Отменено администратором',updated_at=clock_timestamp()
  where id=p_match and status not in ('done','cancelled');
  if not found then raise exception 'Матч уже завершён'; end if;
  return jsonb_build_object('ok',true,'match_id',v_match.id,'status','cancelled','cancel_reason','Отменено администратором');
end;
$function$;
revoke all on function public.cf_lobby_match_admin_action(uuid,text,text) from public,anon;
grant execute on function public.cf_lobby_match_admin_action(uuid,text,text) to authenticated;

-- Reopen legacy matches that were waiting for an administrator to set up a room.
-- The next participant poll returns them to player-only host selection.
update public.cf_lobby_matches
set status='choose_host',admin_id=null,admin_nickname='',updated_at=clock_timestamp()
where status in ('pending_admin','taken')
  and cardinality(accepted_by)>=cardinality(participant_ids)
  and cardinality(participant_ids)>0;

-- Existing restricted queue entries and pre-start matches cannot slip through
-- just because they were created before this migration was installed.
update public.cf_matchmaking_queue q set queue_status='cancelled',updated_at=clock_timestamp()
where q.queue_status='queued' and exists (
  select 1 from unnest(q.party_ids) as member(user_id)
  join public.cf_player_moderation moderation on moderation.user_id=member.user_id
  where moderation.is_permanently_banned or moderation.banned_until>clock_timestamp()
     or moderation.match_restricted_until>clock_timestamp()
);
update public.cf_lobby_matches m
set status='cancelled',cancel_reason='Запуск матчей запрещён действующей модерацией',updated_at=clock_timestamp()
where m.status in ('searching','found','choose_host','host_selected','pending_admin','taken','room','joined')
  and exists (
    select 1 from unnest(m.participant_ids) as member(user_id)
    join public.cf_player_moderation moderation on moderation.user_id=member.user_id
    where moderation.is_permanently_banned or moderation.banned_until>clock_timestamp()
       or moderation.match_restricted_until>clock_timestamp()
  );

commit;

select 'CF FACEIT v46 player room flow, match restrictions and staff cooperation role installed' as result;
